/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define rs_485_Receive  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,GPIO_PIN_RESET);
#define rs_485_Transmit  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15,GPIO_PIN_SET);
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern AT24CXX_HandleTypedef at24cxx_1;
uint8_t txbuff_1[] = "���Ǹ�Ц��ST��˾��ô������أ�";  /*  "����һ�� EEPROM��"
                                {0xCA}
                                "���Ǹ�Ц��ST��˾��ô������أ�"
                             */
uint8_t rxbuff_1[sizeof(txbuff_1)] = {0};

extern W25QXX_HandleTypedef spiFlash_1;
extern W25QXX_HandleTypedef spiFlash_2;
uint8_t rxbuff_2[sizeof(txbuff_1)] = {0};

/* 16λ������ */
uint16_t uhWritedata_16b = 0, flag = 0;

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId myTask02Handle;
osThreadId myTask03Handle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const *argument);
void StartTask02(void const *argument);
void StartTask03(void const *argument);

extern void MX_USB_HOST_Init(void);
void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize);

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize) {
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  /* USER CODE END Init */
  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */
  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */
  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */
  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);
  /* definition and creation of myTask02 */
  osThreadDef(myTask02, StartTask02, osPriorityNormal, 0, 512);
  myTask02Handle = osThreadCreate(osThread(myTask02), NULL);
  /* definition and creation of myTask03 */
  osThreadDef(myTask03, StartTask03, osPriorityIdle, 0, 512);
  myTask03Handle = osThreadCreate(osThread(myTask03), NULL);
  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */
}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const *argument) {
  /* init code for USB_HOST */
  MX_USB_HOST_Init();
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;) {
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_3);
    osDelay(1000);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the myTask02 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void const *argument) {
  /* USER CODE BEGIN StartTask02 */
  extern void usb_test(void);
  extern void sd_to_usb_test(void);
  //    I2C_EE_Init(&at24cxx_1);
  //    W25QXX_Init(&spiFlash_1);
  //    W25QXX_Init(&spiFlash_2);
  //    flag = 1;
  /* Infinite loop */
  for(;;) {
    //        if(HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_14) == GPIO_PIN_SET) {    ///>����Ƿ���
    //            for(;;) {
    //                if(HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_14) == GPIO_PIN_RESET) {     ///>����Ƿ�̧��(������ѹ)
    //                    usb_test();
    //                    sd_to_usb_test();
    //                    break;
    //                }
    //            }
    //        }
    if(at24cxx_1.ready) {
      taskENTER_CRITICAL();    ///>�����ٽ���
      I2C_EE_BufferWrite(&at24cxx_1, txbuff_1, 50, sizeof(txbuff_1));
      I2C_EE_BufferRead(&at24cxx_1, rxbuff_1, 50, sizeof(rxbuff_1));
      taskEXIT_CRITICAL();     ///>�˳��ٽ���
      at24cxx_1.ready = 0;
    }
    if(spiFlash_1.ready == 1 && spiFlash_2.ready == 1) {
      taskENTER_CRITICAL();    ///>�����ٽ���
      W25QXX_Write(&spiFlash_1, txbuff_1, 10, sizeof(txbuff_1));
      W25QXX_Read(&spiFlash_1, rxbuff_1, 10, sizeof(rxbuff_1));
      W25QXX_Write(&spiFlash_2, txbuff_1, 10, sizeof(txbuff_1));
      W25QXX_Read(&spiFlash_2, rxbuff_2, 10, sizeof(rxbuff_2));
      taskEXIT_CRITICAL();     ///>�˳��ٽ���
      spiFlash_1.ready = 0;
      spiFlash_2.ready = 0;
    }
    if(flag == 1) {
#define Bank1_SRAM4_ADDR    ((uint32_t)(0x6C000000))
#define IS62WV51216_SIZE 0x100000  //512*16/2bits = 0x100000  ��1M�ֽ�
      /* ��SRAM����ȫ������Ϊ0 */
      for(uint32_t counter = 0x00; counter < IS62WV51216_SIZE / 2; counter++) {
        *(__IO uint16_t *)(Bank1_SRAM4_ADDR + 2 * counter) = (uint16_t)0x00;
      }
      /* ������SRAMд������  16λ */
      for(uint32_t counter = 0; counter < IS62WV51216_SIZE / 2; counter++) {
        *(__IO uint16_t *)(Bank1_SRAM4_ADDR + 2 * counter) = (uint16_t)(uhWritedata_16b + counter);
      }
      flag = 0;
    }
    osDelay(10);
  }
  /* USER CODE END StartTask02 */
}

/* USER CODE BEGIN Header_StartTask03 */
/**
* @brief Function implementing the myTask03 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask03 */
void StartTask03(void const *argument) {
  /* USER CODE BEGIN StartTask03 */
  /* Infinite loop */
  for(;;) {
    // vTaskList----------------------------------------//
    #if ((configUSE_TRACE_FACILITY != 0) && (configUSE_STATS_FORMATTING_FUNCTIONS != 0))
    char *g_tasks_buf = (char *)pvPortMalloc(512);
    if(g_tasks_buf != NULL) {
      memset(g_tasks_buf, 0, 512);
      strcat((char *)g_tasks_buf, "\n�������� ����״̬ ���ȼ� ʣ���ջ �������\n");
      strcat((char *)g_tasks_buf, "---------------------------------------------\n");
      /* The list of tasks and their status */
      vTaskList((char *)(g_tasks_buf + strlen(g_tasks_buf)));
      strcat((char *)g_tasks_buf, "---------------------------------------------\n");
      //strcat((char *)g_tasks_buf, "B : Blocked, R : Ready, D : Deleted, S : Suspended\r\n");
      strcat((char *)g_tasks_buf, "B : ����, R : ����, D : ɾ��, S : ��ͣ\n");
      rs_485_Transmit;
      printf("%s", g_tasks_buf);
      rs_485_Receive;
      vPortFree(g_tasks_buf);
    } else {
      rs_485_Transmit;
      user_printf("vTaskListӦ�ô���\n");
      rs_485_Receive;
    }
    #endif
    // -------------------------------------------------//
//    vTaskDelete(NULL);
    osDelay(2000);
  }
  /* USER CODE END StartTask03 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
